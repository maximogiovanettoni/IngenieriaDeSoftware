export type ApiError = {
  status?: number;
  message?: string;
};
