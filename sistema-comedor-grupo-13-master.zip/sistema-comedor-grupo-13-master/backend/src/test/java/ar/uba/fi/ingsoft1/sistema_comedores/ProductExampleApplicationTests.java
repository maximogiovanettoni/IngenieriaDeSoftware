package ar.uba.fi.ingsoft1.sistema_comedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
class ProductExampleApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
