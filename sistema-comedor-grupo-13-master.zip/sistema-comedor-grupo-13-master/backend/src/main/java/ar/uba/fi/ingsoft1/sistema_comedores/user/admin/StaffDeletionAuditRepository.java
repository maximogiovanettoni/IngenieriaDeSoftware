package ar.uba.fi.ingsoft1.sistema_comedores.user.admin;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StaffDeletionAuditRepository extends JpaRepository<StaffDeletionAudit, Long> {}
