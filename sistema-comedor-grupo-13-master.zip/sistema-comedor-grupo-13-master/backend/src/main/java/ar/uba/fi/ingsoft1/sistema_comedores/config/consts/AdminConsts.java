package ar.uba.fi.ingsoft1.sistema_comedores.config.consts;

public class AdminConsts {

    public static final String adminAddress = "Paseo Colón 850, CABA";
    
}
