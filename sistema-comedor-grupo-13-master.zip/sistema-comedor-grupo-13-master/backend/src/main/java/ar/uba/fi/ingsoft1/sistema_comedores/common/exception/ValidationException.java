package ar.uba.fi.ingsoft1.sistema_comedores.common.exception;

public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
